<?php

	//Funcion que envia un mensaje a uno o varios destinatarios
	function enviar_mensaje(){
		
		$add['de'] 				= clean_post('de');
		$add['nombre_de'] 		= clean_post('nombre_de');
		$add['asunto'] 			= clean_post('asunto');
		$add['mensaje'] 		= clean_post('mensaje');
		$add['prioridad'] 		= '0';
		$add['eliminado'] 		= '0';
		$add['fecha_creacion']	= datetime();
		
		if(isset($_REQUEST['prioridad']))
			$add['prioridad'] 	= '1';
		else
			$add['prioridad'] 	= '0';
		
		//Obtenemos los destinatarios
		$para = clean_post('para');
		
		$destinatarios = explode(',', $para);
		$total_destina = count($destinatarios);
		
		//Recorremos y enviamos mensajes
		for($i=0; $i<$total_destina; $i++){
			$add['para'] = $destinatarios[$i];
			
			insert('mensajes', $add);
		}
	}
	
	//Funcion que devuelve listado de contactos de un usuario
	function get_listado_contacto(){
	
		$id_usuario = $_SESSION['datos_user']->id_usuario;
		
		$sql = "SELECT * 
				FROM mensajes 
				WHERE para = '".$id_usuario."'
				AND id_mensaje IN (	
									SELECT MAX(id_mensaje)
									FROM mensajes
									WHERE para = '".$id_usuario."'
									AND eliminado = '0'
									GROUP BY de
								  )
				ORDER BY fecha_creacion DESC";
		
		return list_object($sql);
	}
	
	//Funcion que devuelve el id del ultimo que envio un mensaje al conectado
	function get_ultimo_de(){
		$id_usuario = $_SESSION['datos_user']->id_usuario;
		
		$datos = list_object("SELECT * FROM mensajes WHERE para = '".$id_usuario."' ORDER BY fecha_creacion DESC");
		$total = count($datos);
		
		if($total > 0)
			return $datos[0]->de;
		else
			return '0';
	}
	
	//Funcion que devuelve los mensajes de un usuario
	function get_mensajes_de($de){
		$id_usuario = $_SESSION['datos_user']->id_usuario;
		
		return list_object("SELECT * FROM mensajes WHERE para = '".$id_usuario."' AND de = '".$de."' AND eliminado = '0' ORDER BY fecha_creacion DESC");
	}
	
	//Funcion que marca como leidos los mensajes de
	function marcar_leidos_de($de){
		$id_usuario = $_SESSION['datos_user']->id_usuario;
		
		$upd['leido'] = '1';
		
		update('mensajes', $upd, 'para = "'.$id_usuario.'" AND de = "'.$de.'"');
	}
	
	//Funcion que elimina mensaje
	function eliminar_mensaje($id_mensaje){
		$upd['eliminado'] = '1';
		
		update('mensajes', $upd, 'id_mensaje = "'.$id_mensaje.'"');
	}

?>