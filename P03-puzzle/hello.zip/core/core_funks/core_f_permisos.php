<?php
	
	//Funcion que devuelve los permisos en forma de ARRAY
	function get_permisos(){
	
		$rango_usuario = $_SESSION['datos_user']->rango;
	
		$permisos = list_object("SELECT * FROM permisos");
		$total_permisos = count($permisos);
		
		$array_permisos = array();
		
		for($i=0; $i<$total_permisos; $i++){
			$nombre_zona = $permisos[$i]->nombre_zona;
			
			//Guardamos cada zona pero a FALSE
			$array_permisos[$nombre_zona] = false;
		}
		
		$permisos_usuario = list_object("SELECT nombre_zona FROM permisos WHERE FIND_IN_SET($rango_usuario, rangos_permitidos)");
		$total_permisos_usuario = count($permisos_usuario);
		
		for($j=0; $j<$total_permisos_usuario; $j++){
			$nombre_zona_permitida = $permisos_usuario[$j]->nombre_zona;
			
			//Cambiamos los permisos y ponemos a TRUE los disponibles por el usuario
			$array_permisos[$nombre_zona_permitida] = true;
		}
		
		return $array_permisos;
	}
	
	//Funcion que devuelve el listado de permisos
	function get_listado_permisos(){
		return list_object("SELECT * FROM permisos ORDER BY nombre_zona ASC");
	}
	
	//Funcion que inserta un permiso
	function insert_permiso(){
		$newPerm['nombre_zona'] = clean_post('permiso_nombre_zona');
		$newPerm['descripcion'] = clean_post('permiso_descripcion');
		$newPerm['rangos_permitidos'] = clean_post('permiso_rangos');
		
		insert('permisos', $newPerm);
	}
?>