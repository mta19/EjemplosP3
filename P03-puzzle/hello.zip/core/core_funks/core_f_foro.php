<?php

	/* ----------------- FUNCIONES DEL FORO Y POST ----------------- */
	//Funcion que devuelve los datos de un post
	function get_post($id_post){
		return list_object("SELECT * FROM foro WHERE id_foro = '$id_post'");
	}

	//Funcion que devuelve el foro
	function get_foro(){
		$id_grupo = $_SESSION['datos_user']->grupo;
		$buscadorForo = clean_post('buscadorForo');
		
		return list_object("SELECT * FROM foro WHERE id_respuesta = '0' AND id_grupo = '$id_grupo' AND mensaje LIKE '%$buscadorForo%' ORDER BY fecha_creacion DESC");
	}
	
	//Funcion que devuelve las respuestas ordenadas de un post
	function get_respuestas_post($id_post){
		$id_grupo = $_SESSION['datos_user']->grupo;
		
		return list_object("SELECT * FROM foro WHERE id_respuesta = '$id_post' AND id_grupo = '$id_grupo' ORDER BY fecha_creacion ASC");
	}

	//Funcion que inserta un nuevo post en el foro
	function insert_new_post(){
		
		$nombre_completo = $_SESSION['datos_user']->nombre . " " . $_SESSION['datos_user']->apellidos;
		
		$add['id_usuario']			= $_SESSION['datos_user']->id_usuario;
		$add['id_grupo']			= $_SESSION['datos_user']->grupo;
		$add['id_respuesta']		= '0';
		$add['nombre_usuario']		= $nombre_completo;
		$add['titulo']				= clean_post('titulo');
		$add['mensaje']		 		= clean_post('mensaje');
		$add['enlace']				= clean_post('enlace');
		$add['estado']				= '1';
		$add['fecha_creacion']		= datetime();
		$add['fecha_modificacion']	= datetime();
		
		//Insertamos el post
		insert('foro', $add);
		
		$id_post = insert_id();
		
		//Comprobamos si subio imagen
		$ruta = upload_image('area-privada/img/foro/tmp/', 'imagen', 'postImg-'.$id_post);
		
		//Subimos thumbnail
		if($ruta != '0'){
			$upd['imagen'] 		= create_thumbnail($ruta, 290, 190, 'area-privada/img/foro/');
			
			//Eliminamos la temporal subida
			if(file_exists(_PATH_.$ruta))
				unlink(_PATH_.$ruta);
				
			update('foro', $upd, 'id_foro = "'.$id_post.'"');
		}
	}
	
	//Funcion que actualiza un post en el foro
	function update_post(){

		$id_post = clean_post('id_post');
		
		//datos del post
		$datos = get_post($id_post);

		$upd['titulo']				= clean_post('titulo');
		$upd['mensaje']		 		= clean_post('mensaje');
		$upd['enlace']				= clean_post('enlace');
		$upd['fecha_modificacion']	= datetime();
		
		//Comprobamos si subio imagen
		$ruta = upload_image('area-privada/img/foro/tmp/', 'imagen', 'postImg-'.$id_post);
		
		//Subimos thumbnail
		if($ruta != '0'){
			$imagen_ant = $datos[0]->imagen;
			
			if(file_exists(_PATH_.$imagen_ant))
				unlink(_PATH_.$imagen_ant);
			
			$upd['imagen'] 		= create_thumbnail($ruta, 290, 190, 'area-privada/img/foro/');
			
			//Eliminamos la temporal subida
			if(file_exists(_PATH_.$ruta))
				unlink(_PATH_.$ruta);
		}
		
		//Actualizamos post
		update('foro', $upd, 'id_foro = "'.$id_post.'"');
	}

	/* ----------------- FUNCIONES SOBRE COMENTARIOS DEL FORO ----------------- */

	//Funcion que inserta un nuevo comentario en un post
	function insert_new_comment_post(){
	
		$nombre_completo = $_SESSION['datos_user']->nombre . " " . $_SESSION['datos_user']->apellidos;
	
		$add['id_usuario']			= $_SESSION['datos_user']->id_usuario;
		$add['id_grupo']			= $_SESSION['datos_user']->grupo;
		$add['mensaje'] 			= clean_post('comentario');
		$add['id_respuesta']		= clean_post('id_post');
		$add['nombre_usuario']		= $nombre_completo;
		$add['estado']				= '1';
		$add['fecha_creacion']		= datetime();
		$add['fecha_modificacion']	= datetime();
		
		insert('foro', $add);
	}
	
	//Funcion que actualiza un comentario
	function update_comentario(){
		$id_post = clean_post('id_post');
		$upd['mensaje']		 		= clean_post('mensaje');
		$upd['fecha_modificacion']	= datetime();
		
		//Actualizamos post
		update('foro', $upd, 'id_foro = "'.$id_post.'"');
	}
	
	//Funcion que elimina un comentario
	function delete_comentario($id_post){
		query("DELETE FROM foro WHERE id_foro = '$id_post'");
	}

?>