<?php
	function insert_documento()
	{
		$exit=true;
		$titulo = clean_post('titulo');

		$grupo = amigable(get_nombre_grupo($_SESSION['datos_user']->grupo));
		$path = 'area-privada/documentos/'.$grupo.'/';

		$add['titulo'] = clean_post('titulo');
		$add['fecha_creacion'] = datetime();
		$add['fecha_modificacion'] = datetime();

		insert('documentos', $add);

		
		$nombre = $titulo.'-'.insert_id();

		echo upload_documento($path, 'documento',$nombre);
	}
?>