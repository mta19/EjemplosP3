<?php
	
	//Funcion que comprueba que rango maximo puede ver seccion y saber si el usuario puede ver
	function acceso_por_rango($id_rango){
		$rango_usuario = $_SESSION['datos_user']->rango;
		
		if($rango_usuario <= $id_rango)
			return true;
		else
			return false;
	}
?>