<?php

	//Funcion que devuelve los datos de una noticia
	function get_noticia($id_noticia){
		return list_object("SELECT * FROM noticias WHERE id_noticia = '$id_noticia'");
	}

	//Funcion que devuelve las noticias de un grupo
	function get_noticias(){
		$id_grupo = $_SESSION['datos_user']->grupo;
		$buscador = clean_post('buscadorNoticias');
		
		return list_object("SELECT * FROM noticias WHERE id_grupo = '$id_grupo' AND estado = '1' AND titulo LIKE '%$buscador%' ORDER BY fecha_creacion DESC");
	}

	//Funcion que inserta una nueva noticia
	function insert_noticia(){
		$add['id_usuario'] = $_SESSION['datos_user']->id_usuario;
		$add['id_grupo'] = $_SESSION['datos_user']->grupo;
		$add['titulo'] = clean_post('noticia');
		$add['estado'] = '1';
		$add['fecha_creacion'] = datetime();
		$add['fecha_modificacion'] = datetime();
		
		insert('noticias', $add);
	}
	
	//Funcion que actualiza noticia
	function update_noticia(){
		$id_noticia = clean_post('id_noticia');
		$upd['titulo'] = clean_post('noticia');
		$upd['fecha_modificacion'] = datetime();
		
		update('noticias', $upd, 'id_noticia = "'.$id_noticia.'"');
		
		echo "actualizado";
	}
	
	//Funcion que elimina una noticia
	function eliminar_noticia($id_noticia){
		query("DELETE FROM noticias WHERE id_noticia = '$id_noticia'");
	}
?>