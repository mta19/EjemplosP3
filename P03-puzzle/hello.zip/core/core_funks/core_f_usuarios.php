<?php
	
	//Funcion que devuelve todos los miembros de un grupo (incluido el adminitrador de grupo)
	function get_miembros_gupo($id_grupo){
		return list_object("SELECT * FROM usuarios WHERE grupo = '$id_grupo' ORDER BY id_usuario ASC");
	}
	
	//Funcion que devuelve los usuarios de un grupo (incluido el administrador de grupo)
	function get_miembros_paginados($id_grupo, $comienzo, $limite, $applyLimit=true){
	
		$busqueda = clean_post('busqueda');
	
		if($applyLimit)
			$limit = "LIMIT $comienzo, $limite";
		else
			$limit = "";
			
		$sql =	"SELECT * 
			  	 FROM usuarios 
			  	 WHERE grupo = '$id_grupo' 
			  	 AND (concat_ws(' ', nombre, apellidos) LIKE '%$busqueda%'
				 OR telefono LIKE '%$busqueda%'
				 OR email LIKE '%$busqueda%')
			  	 ORDER BY nombre ASC 
			  	 $limit";
		
		return list_object($sql);
	}
	
	//Funcion que devuelve el paginador de los miembros paginados
	function get_paginador_miembros_paginados($id_grupo, $page, $cantidad_por_pagina){
	
		//Total de pujas realizadas para calcular si hay mas pujas que paginas
		$cantidad_total = count(get_miembros_paginados($id_grupo, 0, $cantidad_por_pagina, false));
		
		if ( $cantidad_total > $cantidad_por_pagina ) {
			
			$paginas = ceil($cantidad_total/$cantidad_por_pagina);
			
		  	?>
		  	<ul class="pagination">
            	<?php
					if($page != 1){
						$pagina_anterior = $page-1;
						$comienzo = ($pagina_anterior-1) * $cantidad_por_pagina;
						?><li class="prev"><a href="javascript:void(0)" onclick="ajax_get_miembros('<?=_DOMINIO_?>', <?=$comienzo?>, <?=$cantidad_por_pagina?>, <?=$pagina_anterior?>);"><i class="fa fa-angle-double-left"></i></a></li><?php
					}
				?>
                <?php
                $show_pages = 10;
                $start = $page > ($show_pages/2) ? $page-($show_pages/2) : 1; 
                $finish = $start+$show_pages > $paginas ? $paginas : $start+$show_pages;
                $start = $finish-$show_pages < 1 ? 1 : $finish-$show_pages;
                for ( $i=$start; $i<=$finish; $i++ ) {
					$comienzo = ($i-1) * $cantidad_por_pagina;
                	?><li class="<?=$page == $i ? 'active' : '' ?>"><a href="javascript:void(0)" onclick="ajax_get_miembros('<?=_DOMINIO_?>', <?=$comienzo?>, <?=$cantidad_por_pagina?>, <?=$i?>);"><?=$i?></a></li><?php 
                }
				
					if($page != $finish){
						$pagina_siguiente= $page+1;
						$comienzo = ($pagina_siguiente-1) * $cantidad_por_pagina;
						?><li class="next"><a href="javascript:void(0)" onclick="ajax_get_miembros('<?=_DOMINIO_?>', <?=$comienzo?>, <?=$cantidad_por_pagina?>, <?=$pagina_siguiente?>);"><i class="fa fa-angle-double-right"></i></a></li><?php
					}
				
                ?>
           	</ul>
		  	<?php
		 }
	}
	
	//Funcion que devuelve los datos del usuario segun id
	function get_user_by_id($id_usuario){
		return list_object("SELECT * FROM usuarios WHERE id_usuario = '$id_usuario'");
	}
	
	//Funcion que devuelve los datos del usuario segun su password
	function get_user_by_password($usuario, $password){
		return list_object("SELECT * FROM usuarios WHERE usuario = '$usuario' AND password = '$password'");
	}

	//Funcion que comprueba login
	function comprobar_login(){
		
		$usuario 	= clean_post('usuario');
		$password 	= secure_md5(clean_post('password'));
		
		if(num_rows("SELECT * FROM usuarios WHERE usuario = '$usuario' AND password = '$password'") > 0){
			//Datos del usuario			
			$datos_usuario = get_user_by_password($usuario, $password);
			$estado = $datos_usuario[0]->estado;
			
			if($estado){
				$_SESSION['datos_user'] = $datos_usuario[0];
				return "login";
			}
			else
				return "inactiva";
		}
		else
			return "error";
	}
	
	//Funcion que comprueba si una contrase�a esta siendo usada
	function comprobar_password_disponible($password, $id_usuario=""){
		
		$password_enc = secure_md5($password);
		$id_grupo = $_SESSION['datos_user']->grupo;
		
		if($id_usuario != "")
			$sql = "SELECT * FROM usuarios WHERE password = '$password_enc' AND id_usuario != '$id_usuario' AND grupo = '$id_grupo'";
		else
			$sql = "SELECT * FROM usuarios WHERE password = '$password_enc' AND grupo = '$id_grupo'";
		
		if(num_rows($sql) > 0)
			return false;
		else
			return true;
	}
	
	//Funcion que actualiza el estado del miembro
	function actualizar_estado_miembro($id_usuario){
		$datos_usuario = get_user_by_id($id_usuario);
		$estado = $datos_usuario[0]->estado;
		
		if($estado == '1'){
			$upd['estado'] = '0';
			echo "desactivado";
		}
		else{
			$upd['estado'] = '1';
			echo "activado";
		}
		
		update('usuarios', $upd, 'id_usuario = "'.$id_usuario.'"');
	}
	
	//Funcion que inserta un miembro
	function insert_miembro(){
		$nombre = clean_post('nombre');
		$add['nombre'] = clean_post('nombre');
		$add['apellidos'] = clean_post('apellidos');
		$add['telefono'] = clean_post('telefono');
		$add['email'] = clean_post('email');
		$add['usuario'] = clean_post('usuario');
		$add['password'] = secure_md5(clean_post('password'));
		$add['grupo'] = clean_post('grupo');
		$add['cod_grupo'] = clean_post('password');
		$add['rango'] =  '3';
		$add['estado'] = '1';
		$add['fecha_creacion'] = datetime();
		$add['fecha_modificacion'] = datetime();
		
		//Insertamos usuario
		insert('usuarios', $add);
		
		$id_usuario = insert_id();
		
		//Comprobamos si subio imagen
		$ruta = upload_image('area-privada/img/usuarios/tmp/', 'imagen', amigable($nombre).'-'.$id_usuario);
		
		//Subimos thumbnail
		if($ruta != '0'){
			$upd['imagen'] 		= create_thumbnail($ruta, 200, 200, 'area-privada/img/usuarios/');
			
			//Eliminamos la temporal subida
			if(file_exists(_PATH_.$ruta))
				unlink(_PATH_.$ruta);
				
			update('usuarios', $upd, 'id_usuario = "'.$id_usuario.'"');
		}
		
	}
	
	//Funcion que actualiza un miembro
	function update_miembro($id_usuario){
		
		$nombre = clean_post('nombre');
		$password = clean_post('password');
		
		$upd['nombre'] = clean_post('nombre');
		$upd['apellidos'] = clean_post('apellidos');
		$upd['telefono'] = clean_post('telefono');
		$upd['email'] = clean_post('email');
		$upd['fecha_modificacion'] = datetime();
		
		//En caso de modificar password
		if($password != ""){
			$upd['password'] = secure_md5(clean_post('password'));
			$upd['cod_grupo'] = clean_post('password');
		}
		
		if(isset($_REQUEST['firma']) && $_REQUEST['firma'] != "")
			$upd['firma'] = clean_post('firma');
		
		//Comprobamos si subio imagen
		$ruta = upload_image('area-privada/img/usuarios/tmp/', 'imagen', amigable($nombre).'-'.$id_usuario);
		
		if($ruta != '0'){
			//Obtenemos los datos del miembro para eliminar la antigua foto
			$datos = get_user_by_id($id_usuario);
			$total = count($datos);
			
			//En caso de que exista...
			if($total > 0){
				$imagen_act = $datos[0]->imagen;
				
				//Eliminamos la imagen actual del miembro en caso de que tenga
				if(file_exists(_PATH_.$imagen_act))
					unlink(_PATH_.$imagen_act);
			}
			
			$upd['imagen'] 		= create_thumbnail($ruta, 200, 200, 'area-privada/img/usuarios/');
			
			//Eliminamos la temporal subida
			if(file_exists(_PATH_.$ruta))
				unlink(_PATH_.$ruta);
		}
		
		update('usuarios', $upd, 'id_usuario = "'.$id_usuario.'"');
	}
	
	//Funcion que elimina un miembro
	function eliminar_miembro($id_usuario){
		
		$datos_usuario = get_user_by_id($id_usuario);
		$total_usuario = count($datos_usuario);
		
		if($total_usuario > 0){
			//Obtenemos su imagen, ya que en caso de que tenga la eliminaremos
			$imagen = $datos_usuario[0]->imagen;
			
			if(file_exists(_PATH_.$imagen))
				unlink(_PATH_.$imagen);
			
			//Elimino el miebro
			query("DELETE FROM usuarios WHERE id_usuario = '$id_usuario'");
		}
	}
	
	//Funcion que devuelve el nombre de un grupo
	function get_nombre_grupo($id_grupo){
		$datos = list_object("SELECT * FROM grupos WHERE id_grupo = '$id_grupo'");
		
		return $datos[0]->nombre;
	}
	
	// Funcion que genera una password
	function generar_password(){
		
		$cad = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
		$password = "";
		$totalCad = strlen($cad);
		
		for($i=0;$i<8;$i++) 
		{
			$password .= substr($cad,rand(0,$totalCad),1);
		}
		
		return $password;
	}
?>