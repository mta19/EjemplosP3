<?php
//Enviamos 1 email
function send_email($destinatario,$asunto,$mensaje)
{
	require_once(_PATH_."core/core_clases/class.phpmailer.php");
	
	$destinatario = $destinatario; //Prueba
	
	$mail = new PHPMailer();
	$mail->IsSMTP();                       					
	$mail->Host = _SMTP_SERVER_;     		
	$mail->SMTPAuth = true;  
	
	$puerto[0] = 25;
	$puerto[1] = 587;
	   		   					
	$mail->Port = _SMTP_PORT_;
	$mail->SetFrom(_SMTP_USER_, _TITULO_);             					
	$mail->Username = _SMTP_USER_;  
	$mail->Password = _SMTP_PASSWORD_; 							
	$mail->SetLanguage("es");
	$mail->CharSet = _SMTP_CHARSET_ISO_;
	$mail->WordWrap = 50;     								
	$mail->IsHTML(true);      	
	$mail->AltBody = "";
	$mail->AddAddress($destinatario, _TITULO_);
	$mail->Subject = $asunto;
	$mail->Body = $mensaje;
	$mail->From = _SMTP_USER_;
	$mail->FromName = 'Formulario de contacto - Grupomastermind.es';
	
	if( !$mail->Send() ) {
		return false;
	}
	else {
		return true;	
	}
}

//Enviamos un email corporativo
function send_email_corporativo($destinatario,$asunto,$mensaje) {
	$mensaje = '
		<div style="width:100%; height:100%; background-color:#f0f0f0; text-align:center; font-size:12px; color:#333;">
			<br /><br />
			Este es un email autom&aacute;tico. Por favor no responda directamente a el.
			<br /><br />
			<div style="border:1px solid #ccc; background-color:#fff; padding:26px; width:860px; color:#333; font-size:14px; line-height:22px; text-align:left;">
				'.$mensaje.'
				<br /><br />
				Enviado desde: <a href="http://www.grupomastermind.es" style="color: #D8A109;">www.grupomastermind.es</a>
				<br /><br />
				<div style="border-top:1px solid #ccc; padding-top:24px; font-size:12px; color:#666;">
					Este email ha sido enviado autom&aacute;ticamente desde '._DOMINIO_.'. <a href="'._DOMINIO_.'politica-de-privacidad/" style="color: #D8A109;">pol&iacute;tica de privacidad</a>
				</div>
			</div>
			<br /><br />
		</div>
	';
	return send_email($destinatario,$asunto,$mensaje);  
}

?>