<?php

/*
	Utilidades de seguridad
*/

/* Encriptación segura */
function secure_md5($val)
{
	$val = md5($val);
	$val = $val._SECURITY_TOKEN_.$val._SECURITY_TOKEN_.$val;
	$val = md5($val);
	$val = md5($val);
	return $val;
}

/* Encripta */
function en__($v)
{
	return base64_encode( base64_encode( base64_encode($v) ) );	
}

/* Desencripta */
function de__($v)
{
	return base64_decode( base64_decode( base64_decode($v) ) );			
}

function clean_int($var) {
	return (int)$var;		
}

function clean_post($var) {
	if ( isset($_POST[$var]) ) {
		return trim( addslashes( strip_tags( $_POST[$var] )));	
	}
	else { 
		return false;
	}
}

function clean_session($var) {
	return trim( addslashes( strip_tags( $_SESSION[$var] )));		
}

function clean_get($var) {
	if ( isset($_GET[$var]) ) {
		return trim( addslashes( strip_tags( $_GET[$var] )));
	}
	else { 
		return false;
	}		
}

function is_home() {
	if ( isset($_GET['mod']) )
		return false;	
	else
		return true;	
}

function log_($message) {
	$f = _PATH_.log_folder.'log';
	
	$size = @filesize($f);
	if ( $size > log_max_kb*1024 ) {	
		rename($f,$f.'_'.date('Y-m-d_H-i-s'));
		
		$file = @fopen($f,'a');
		@fwrite($file, date('Y-m-d H:i:s').' - '.$message.PHP_EOL);
		@fclose($file);
	}
	else {
		$file = @fopen($f,'a');
		@fwrite($file, date('Y-m-d H:i:s').' - '.$message.PHP_EOL);
		@fclose($file);
	}
}

/* Configuracion obtenida de la BD */
function get_conf() {
	$conf = list_object('SELECT * FROM configuracion');
	$count_conf = count($conf);
	for ( $i=0; $i<$count_conf; $i++ ) {
		define($conf[$i]->nombre,$conf[$i]->valor); 
		//echo "Defines: " . $conf[$i]->nombre . " (".$conf[$i]->valor.")<br/>";
	}
}

?>