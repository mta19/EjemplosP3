<?php

/*
	Utilidades
*/

/* Encode UTF-8 */
function u8_($var) {
	return utf8_encode($var);
}

/* Decode UTF-8 */
function u8d_($var) {
	return utf8_decode($var);
}

/* Sube imagen (si hay) a la ruta mandad) */
function upload_image($ruta, $nombre, $nombre_imagen)
{	

	if($_FILES[$nombre]["name"] != '')
	{
		$ruta_completa = _PATH_ . $ruta;
	
		//Comprobamos el directorio ya que si no lo creamos
		if(!file_exists($ruta_completa))
			mkdir ($ruta_completa, 0777, true);
			
		$nombrecompleto = $_FILES[$nombre]["name"];
		$extension = extension_($nombrecompleto);
		
		if($extension == "jpg" || $extension == "JPG" ||$extension == "jpeg" || $extension == "JPEG" || $extension == "png" || $extension == "PNG"){
			$ico = "$nombre_imagen.$extension";
			$temp = $_FILES[$nombre]['tmp_name'];
			$ruta_bd = $ruta . $ico;	// Ruta que se almacenará en la base de datos para mostrar.
			$ruta = _PATH_.$ruta;		// Ruta absoluta desde el path. Para agregar la imagen al sitio que le corresponde.
			move_uploaded_file($temp, $ruta . $ico);
			return $ruta_bd;
		}
		else
			return "0";
	}
	else
		return '0';
}

/* Crea una imagen Thumbnail - RutaImagenOriginal, Ancho que quiere, Alto que quieres, Ruta donde guardar. Y ¡waaala!, te redimensiona la imagen.*/
function create_thumbnail($ruta, $ancho_definido, $alto_definido, $ruta_guardado)
{
	$ruta_completa_thum = _PATH_ . $ruta_guardado;
	
	//Comprobamos el directorio ya que si no lo creamos
	if(!file_exists($ruta_completa_thum))
		mkdir ($ruta_completa_thum, 0777, true);

	//Nos disponemos a crear la imagen thumbnail.
	$ruta_imagen_original = _PATH_ . $ruta;
	
	//Obtenemos la extension separando la ruta
	$array_ruta = explode("/", $ruta);
	$nombre_completo = explode(".", $array_ruta[count($array_ruta)-1]);
	$nombre_imagen = $nombre_completo[0];
	$extension = $nombre_completo[1];
	
	//Creamos una variable imagen a partir de la imagen original. Teniendo en cuenta la extension
	if($extension == "jpeg" || $extension == "jpg")
		$img_original = imagecreatefromjpeg($ruta_imagen_original);
	elseif($extension == "png")
		$img_original = imagecreatefrompng($ruta_imagen_original);
	
	//Obtenemos el tamaño original de la imagen
	list($ancho, $alto)=getimagesize($ruta_imagen_original);
	
	$ancho_final = $ancho_definido;
	
	//Calculando Alto
	$alto_final = round(($alto)/($ancho/$ancho_final), 0);
	
	//Creamos una imagen en blanco de tamaño $ancho_final  por $alto_final .
	$thumbnail_tmp = imagecreatetruecolor($ancho_final,$alto_final);
	
	if($extension == 'png'){
		imagecolortransparent($thumbnail_tmp, imagecolorallocatealpha($thumbnail_tmp, 0, 0, 0, 127));
		imagealphablending($thumbnail_tmp, false);
 		imagesavealpha($thumbnail_tmp, true);
	}
	
	//Copiamos $img_original sobre la imagen que acabamos de crear en blanco ($thumbnail_tmp)
	imagecopyresampled($thumbnail_tmp, $img_original, 0, 0, 0, 0, $ancho_final, $alto_final, $ancho, $alto);
	
	//Se destruye variable $img_original para liberar memoria
	imagedestroy($img_original);
	
	//Definimos la calidad de la imagen final
	$calidad = 80;
	$ruta_carpeta_thumbnail = $ruta_guardado.$nombre_imagen.".".$extension;
	
	//Comprobamos la extension otra vez
	if($extension == "jpeg" || $extension == "jpg")
		//Se crea la imagen final en el directorio indicado
		imagejpeg($thumbnail_tmp, _PATH_.$ruta_carpeta_thumbnail,$calidad);
	elseif($extension == "png"){
		imagepng($thumbnail_tmp,_PATH_.$ruta_carpeta_thumbnail);
	}
		
	return $ruta_carpeta_thumbnail;	
}

/* Funcion que sube un documento */
function upload_documento($ruta, $nombre, $nombre_archivo)
{	

	if(is_uploaded_file($_FILES[$nombre]["tmp_name"]))
	{
		$ruta_completa = _PATH_ . $ruta;
	
		//Comprobamos el directorio ya que si no lo creamos
		if(!file_exists($ruta_completa))
			mkdir ($ruta_completa, 0777, true);
	
		$nombrecompleto = $_FILES[$nombre]["name"];
		// $nombrecompleto = $nombre_archivo;
		$extension = strstr($nombrecompleto,".");
		
		if($extension == ".pdf" || $extension == ".PDF"){
			// $ico = $_FILES[$nombre]['name'];
			$ico = $nombre_archivo;
			$temp = $_FILES[$nombre]['tmp_name'];
			$ico =  amigable(str_replace($extension, "", $ico)) . $extension;
			$ruta_bd = $ruta . $ico;	// Ruta que se almacenará en la base de datos para mostrar.
			$ruta = _PATH_.$ruta;		// Ruta absoluta desde el path. Para agregar la imagen al sitio que le corresponde.
			move_uploaded_file($temp, $ruta . $ico);
			return $ruta_bd;
		}
		else{
			$ruta_bd = "0"; // 0 Indicando que si es 0 se mostrará una imagen por defecto. (IMAGEN NO DISPONIBLE X)
			return $ruta_bd;
		}
	}
	else
		return '0';
}

/* Formatea fecha */
function dateTOfecha($input){
	$input = explode('-',$input);
	$input = $input[2].'/'.$input[1].'/'.$input[0];
	return $input;
}

/* Formatea datetime y le da la vuelta */
function datetimeTOinverse($input){
	$input = explode(' ',$input);
	$tiempo= $input[1];
	$input = explode('-',$input[0]);
	$input = $input[2].'/'.$input[1].'/'.$input[0];
	return $input;
}

/* Funcion que convierte a DATE */
function cDate($fecha){
	$fecha_sep = explode(" ", $fecha);
	return $fecha_sep[2]."-".$fecha_sep[1]."-".$fecha_sep[0];
}

/* Devuelve la extension de un archivo */
function extension_($file) {
	$ext = explode('.',$file);
	$ext = $ext[count($ext)-1];
	return strtolower($ext);	
}

/* URLs amigables */
function amigable($var) {  	  
    $wrong = array('á', 'é', 'í', 'ó', 'ú', 'ñ', 'Á', 'É', 'Í', 'Ó', 'Ú', 'Ñ', 'ç', 'ü');  
    $right = array('a', 'e' ,'i', 'o', 'u', 'n', 'A', 'E', 'I', 'O', 'U', 'N', 'c', 'u');  
    $var = str_replace($wrong, $right, $var); 
    $var = strtolower($var);  
    $var = preg_replace("/[^a-z0-9]+/", "-", $var);
    $var = trim($var, '-'); 
	return $var;  
}  

//Funcion que comprueba si tiene formato valido email
function check_mail($mail){
	if (filter_var($mail, FILTER_VALIDATE_EMAIL))
        return true;
	else
		return false;
}

//Funcion datetime()
function datetime()
{
    $fecha = date("Y") ."-". date("m") ."-". date("d");
    $fecha .= " ";
    $fecha .= date("H") .":". date("i") .":". date("s");
    
    return($fecha);
}

//Funcion que devuelve iniciales del mes
function get_inicial_mes($num_mes){
	
	$meses = array(
		'01' => 'Ene',
		'02' => 'Feb',
		'03' => 'Mar',
		'04' => 'Abr',
		'05' => 'May',
		'06' => 'Jun',
		'07' => 'Jul',
		'08' => 'Ago',
		'09' => 'Sep',
		'10' => 'Oct',
		'11' => 'Nov',
		'12' => 'Dic'
	);
	
	return $meses[$num_mes];
}

//Funcion que devuelve el mes segun dia
function get_mes($num_mes){
	
	$meses = array(
		'01' => 'Enero',
		'02' => 'Febrero',
		'03' => 'Marzo',
		'04' => 'Abril',
		'05' => 'Mayo',
		'06' => 'Junio',
		'07' => 'Julio',
		'08' => 'Agosto',
		'09' => 'Septiembre',
		'10' => 'Octubre',
		'11' => 'Noviembre',
		'12' => 'Diciembre'
	);
	
	return $meses[$num_mes];
}

//Funcion que devuelve la fecha escrita formal.
function get_formaldate($date){
	$fecha_sep = explode("-", $date);
	$anyo_serv = $fecha_sep[0];
	$mes_serv = $fecha_sep[1];
	$dia_serv = $fecha_sep[2];
	
	$fecha = $dia_serv . " de " . get_mes($mes_serv) . " del " . $anyo_serv;
	
	return $fecha;
}

/* Devuelve las provincias */
function get_provincias(){
	return list_object("SELECT * FROM provincias ORDER BY nombre;");
}

/* Devuelve el nombre de la provincia segun id */
function get_provincia($id)
{
	$prov = list_object("SELECT nombre FROM provincias WHERE idprovincia = '$id' ");
	
	return $prov[0]->nombre;
}

//Funcion que limpia una cadena
function urlfix($url){
 	$url = str_replace('http://', '', $url);
 	$url = str_replace('https://', '', $url); 
 	return 'http://'.$url;
}

//Limita caracteres y añade puntos suspensivos
function limita($c,$v) {
	echo strlen($v) > $c ? substr($v,0,$c).'...' : $v;	
}

//Redireccion javascript
function location($url) {
	?>
    <script language="javascript">
		document.location='<?=$url?>';
	</script>
    <?php	
}

function edad($fecha_nac){
	$dia 	= date("j");
	$mes	= date("n");
	$anno 	= date("Y");
	
	$dia_nac 	= substr($fecha_nac, 8, 2);	
	$mes_nac 	= substr($fecha_nac, 5, 2);
	$anno_nac 	= substr($fecha_nac, 0, 4);
	
	if($mes_nac>$mes)
		$calc_edad= $anno-$anno_nac-1;
	else{
		if($mes==$mes_nac AND $dia_nac>$dia)
			$calc_edad= $anno-$anno_nac-1;
		else
			$calc_edad= $anno-$anno_nac;
	}
	
	return $calc_edad;
}

//Mensaje al redireccionar
function redir_message($message) {
 ?>
    <div style="position:absolute; width:100%; height:100%; background-color:#000; top:0; left:0; z-index:2000; opacity: 0.7; filter: alpha(opacity=75);"></div>
    <div style="position:fixed; top:50%; left:50%; background-color:#fff; width:500px; height:300px; margin-left:-250px; border-radius:5px; margin-top:-150px; border:1px solid #ccc; z-index:3000; text-align:center">
     <br /><br /><br />
        <img src="<?=_DOMINIO_?>img/logo-loading.png" width="350" />
        <br /><br /><br />
 	 <span style="font-family: Oxygen; font-size:18px; color:#666;"><?=$message?></span>
        <br /><br /><br />
        <img src="<?=_DOMINIO_?>img/loading.gif" width="200" />
    </div>
    <?php  
}

//Redireccion javascript
function location_time($url,$time=0) {
	 if ( $time != 0 ) {
		?>
		  <script language="javascript">
		   setTimeout("document.location='<?=$url?>'",<?=$time?>);
		  </script>
		<?php  
	 }
	 else {
		?>
		  <script language="javascript">
		   document.location='<?=$url?>';
		  </script>
		<?php
	}
}

//Recorre texto y detecta enlaces
function textToLink($text){
        $text = html_entity_decode($text);
        $text = " ".$text;
  return preg_replace(array(
    '/(?(?=<a[^>]*>.+<\/a>)
    (?:<a[^>]*>.+<\/a>)
    |
    ([^="\']?)((?:https?|ftp|bf2|):\/\/[^<> \n\r]+)
   )/iex',
    '/<a([^>]*)target="?[^"\']+"?/i',
    '/<a([^>]+)>/i',
    '/(^|\s)(www.[^<> \n\r]+)/iex',
    '/(([_A-Za-z0-9-]+)(\\.[_A-Za-z0-9-]+)*@([A-Za-z0-9-]+)
    (\\.[A-Za-z0-9-]+)*)/iex'
    ),
  array(
    "stripslashes((strlen('\\2')>0?'\\1<a href=\"\\2\">\\2</a>\\3':'\\0'))",
    '<a\\1',
    '<a\\1 target="_blank">',
    "stripslashes((strlen('\\2')>0?'\\1<a href=\"http://\\2\" target=\"_blank\">\\2</a>\\3':'\\0'))",
    "stripslashes((strlen('\\2')>0?'<a href=\"mailto:\\0\">\\0</a>':'\\0'))"
    ),
 $text);
}


//Cargamos Facebox
function load_facebox($element) {
	?>
    <link rel="stylesheet" href="<?=_DOMINIO_?>js/facebox/facebox.css" />
    <script language="javascript" src="<?=_DOMINIO_?>js/facebox/facebox.js"></script>
    <script language="javascript" src="<?=_DOMINIO_?>js/facebox/sombraNegra.js"></script>
    <script>
		$(document).ready(function() {
        	$('<?=$element?>').facebox({
				loadingImage : '<?=_DOMINIO_?>js/facebox/img/loading.gif',
      			closeImage   : '<?=_DOMINIO_?>js/facebox/img/closelabel.gif',		
			});  
        });
	</script>
    <?php
}

//Cargamos Lightbox
function load_lightbox($element) {
	?>
    <link rel="stylesheet" href="<?=_DOMINIO_?>js/lightbox/lightbox.css" />
    <script language="javascript" src="<?=_DOMINIO_?>js/lightbox/lightbox.js"></script>
    <script>
		$(document).ready(function() {
        	$('<?=$element?>').lightBox({
				imageLoading:  '<?=_DOMINIO_?>js/lightbox/images/loading.gif',		
				imageBtnPrev:  '<?=_DOMINIO_?>js/lightbox/images/prevlabel.gif',	
				imageBtnNext:  '<?=_DOMINIO_?>js/lightbox/images/nextlabel.gif',			
				imageBtnClose: '<?=_DOMINIO_?>js/lightbox/images/closelabel.gif',
				imageBlank:    '<?=_DOMINIO_?>js/lightbox/images/bullet.gif',
			});  
        });
	</script>
    <?php
}	

?>